package com.t3es2.cadastramento_geral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastramentoGeralApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastramentoGeralApplication.class, args);
	}

}
