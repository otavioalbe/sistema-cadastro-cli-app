package com.t3es2.cadastramento_geral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastramentoGeralApplicationTests {

	@Test
	void contextLoads() {
	}

}
